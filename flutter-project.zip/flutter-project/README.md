# POTO GRAPER — Flutter Release Ready

Project Flutter sudah disusun agar kompatibel dengan workflow build yang memakai folder `flutter-project`.

Fitur:
- Camera
- Gallery / multi-photo selection
- Crop
- Rotate
- Flip horizontal / vertical
- Brightness
- Contrast
- Saturation
- Preset filters
- Reset
- Save/export
- Share
- Edit history
- Dark/light mode
- Android release configuration

## Struktur ZIP

```text
POTO_GRAPER_FIXED.zip
├── flutter-project/
│   ├── pubspec.yaml
│   ├── lib/
│   └── android/
└── build-assets/
    └── icon.png
```

`pubspec.yaml` menggunakan Dart SDK >=3.8 sehingga workflow yang memilih Flutter 3.35.2 tidak gagal karena constraint SDK.
