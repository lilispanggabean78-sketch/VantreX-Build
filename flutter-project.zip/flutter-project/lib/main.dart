import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

void main() => runApp(const PhotoStudioApp());

class PhotoStudioApp extends StatefulWidget {
  const PhotoStudioApp({super.key});

  @override
  State<PhotoStudioApp> createState() => _PhotoStudioAppState();
}

class _PhotoStudioAppState extends State<PhotoStudioApp> {
  ThemeMode mode = ThemeMode.dark;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'POTO GRAPER',
      debugShowCheckedModeBanner: false,
      themeMode: mode,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        colorSchemeSeed: Colors.deepPurple,
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorSchemeSeed: Colors.deepPurple,
      ),
      home: EditorPage(
        isDark: mode == ThemeMode.dark,
        onToggleTheme: () => setState(() {
          mode = mode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark;
        }),
      ),
    );
  }
}

class EditorPage extends StatefulWidget {
  final bool isDark;
  final VoidCallback onToggleTheme;

  const EditorPage({
    super.key,
    required this.isDark,
    required this.onToggleTheme,
  });

  @override
  State<EditorPage> createState() => _EditorPageState();
}

class _EditorPageState extends State<EditorPage> {
  final ImagePicker picker = ImagePicker();

  Uint8List? originalBytes;
  Uint8List? editedBytes;
  final List<Uint8List> history = [];

  double brightness = 0;
  double contrast = 0;
  double saturation = 0;
  String filter = 'Original';
  int quarterTurns = 0;
  bool flipX = false;
  bool flipY = false;
  bool busy = false;

  final filters = const [
    'Original',
    'Mono',
    'Sepia',
    'Warm',
    'Cool',
    'Vintage',
    'Dramatic',
  ];

  Future<void> pick(ImageSource source) async {
    final file = await picker.pickImage(
      source: source,
      imageQuality: 100,
    );
    if (file == null) return;
    await loadFile(File(file.path));
  }

  Future<void> loadFile(File file) async {
    setState(() => busy = true);
    try {
      final bytes = await file.readAsBytes();
      originalBytes = bytes;
      editedBytes = bytes;
      history.clear();
      _resetControls();
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  void _resetControls() {
    brightness = 0;
    contrast = 0;
    saturation = 0;
    filter = 'Original';
    quarterTurns = 0;
    flipX = false;
    flipY = false;
  }

  Future<void> crop() async {
    if (editedBytes == null) return;
    final dir = await getTemporaryDirectory();
    final input = File('${dir.path}/crop_input.jpg');
    await input.writeAsBytes(editedBytes!);

    final result = await ImageCropper().cropImage(
      sourcePath: input.path,
      compressFormat: ImageCompressFormat.jpg,
      compressQuality: 95,
      uiSettings: [
        AndroidUiSettings(
          toolbarTitle: 'Crop Photo',
          toolbarColor: Colors.deepPurple,
          toolbarWidgetColor: Colors.white,
          lockAspectRatio: false,
        ),
        IOSUiSettings(title: 'Crop Photo'),
      ],
    );

    if (result == null) return;
    await _commit(await File(result.path).readAsBytes());
  }

  Future<void> transform({bool rotate = false, bool horizontal = false}) async {
    if (editedBytes == null) return;
    final decoded = img.decodeImage(editedBytes!);
    if (decoded == null) return;

    final next = img.copyRotate(
      decoded,
      angle: rotate ? 90 : 0,
    );
    final transformed = horizontal ? img.flipHorizontal(next) : next;
    final finalImage = horizontal ? transformed : next;

    if (!rotate && !horizontal) return;

    await _commit(Uint8List.fromList(img.encodeJpg(finalImage, quality: 95)));
    if (rotate) {
      quarterTurns = (quarterTurns + 1) % 4;
    } else {
      flipX = !flipX;
    }
  }

  Future<void> flipVertical() async {
    if (editedBytes == null) return;
    final decoded = img.decodeImage(editedBytes!);
    if (decoded == null) return;
    final next = img.flipVertical(decoded);
    await _commit(Uint8List.fromList(img.encodeJpg(next, quality: 95)));
    flipY = !flipY;
  }

  Future<void> applyAdjustments() async {
    if (editedBytes == null) return;
    final decoded = img.decodeImage(editedBytes!);
    if (decoded == null) return;

    var output = img.adjustColor(
      decoded,
      brightness: brightness,
      contrast: contrast + 1,
      saturation: saturation + 1,
    );

    switch (filter) {
      case 'Mono':
        output = img.grayscale(output);
        break;
      case 'Sepia':
        output = img.sepia(output);
        break;
      case 'Warm':
        output = img.adjustColor(output, saturation: 1.15, gamma: 0.95);
        break;
      case 'Cool':
        output = img.adjustColor(output, saturation: 0.95, gamma: 1.05);
        break;
      case 'Vintage':
        output = img.sepia(output, amount: 0.35);
        break;
      case 'Dramatic':
        output = img.adjustColor(output, contrast: 1.25, saturation: 1.1);
        break;
    }

    await _commit(Uint8List.fromList(img.encodeJpg(output, quality: 95)));
  }

  Future<void> _commit(Uint8List bytes) async {
    if (editedBytes != null) history.add(editedBytes!);
    editedBytes = bytes;
    if (history.length > 30) history.removeAt(0);
    if (mounted) setState(() {});
  }

  Future<void> undo() async {
    if (history.isEmpty) return;
    editedBytes = history.removeLast();
    if (mounted) setState(() {});
  }

  Future<void> reset() async {
    if (originalBytes == null) return;
    await _commit(originalBytes!);
    _resetControls();
    if (mounted) setState(() {});
  }

  Future<File?> saveFile() async {
    if (editedBytes == null) return null;
    final dir = await getApplicationDocumentsDirectory();
    final file = File(
      '${dir.path}/photo_studio_${DateTime.now().millisecondsSinceEpoch}.jpg',
    );
    await file.writeAsBytes(editedBytes!);
    return file;
  }

  Future<void> save() async {
    final file = await saveFile();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(file == null ? 'Belum ada foto' : 'Foto disimpan')),
    );
  }

  Future<void> share() async {
    final file = await saveFile();
    if (file == null) return;
    await SharePlus.instance.share(
      ShareParams(
        text: 'Dibuat dengan Photo Studio',
        files: [XFile(file.path)],
      ),
    );
  }

  Widget toolButton(
    String label,
    IconData icon,
    VoidCallback action,
  ) {
    return FilledButton.tonalIcon(
      onPressed: busy || editedBytes == null ? null : action,
      icon: Icon(icon),
      label: Text(label),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bytes = editedBytes;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Photo Studio'),
        actions: [
          IconButton(
            tooltip: 'Undo',
            onPressed: history.isEmpty ? null : undo,
            icon: const Icon(Icons.undo),
          ),
          IconButton(
            tooltip: 'Tema',
            onPressed: widget.onToggleTheme,
            icon: Icon(widget.isDark ? Icons.light_mode : Icons.dark_mode),
          ),
        ],
      ),
      body: busy
          ? const Center(child: CircularProgressIndicator())
          : SafeArea(
              child: Column(
                children: [
                  Expanded(
                    child: Container(
                      margin: const EdgeInsets.all(12),
                      width: double.infinity,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(22),
                        color: Theme.of(context).colorScheme.surfaceContainer,
                      ),
                      clipBehavior: Clip.antiAlias,
                      child: bytes == null
                          ? _emptyState()
                          : InteractiveViewer(
                              minScale: 0.5,
                              maxScale: 4,
                              child: Center(
                                child: Image.memory(bytes, fit: BoxFit.contain),
                              ),
                            ),
                    ),
                  ),
                  SizedBox(
                    height: 220,
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: [
                              toolButton('Camera', Icons.camera_alt, () => pick(ImageSource.camera)),
                              toolButton('Gallery', Icons.photo_library, () => pick(ImageSource.gallery)),
                              toolButton('Crop', Icons.crop, crop),
                              toolButton('Rotate', Icons.rotate_right, () => transform(rotate: true)),
                              toolButton('Flip X', Icons.flip, () => transform(horizontal: true)),
                              toolButton('Flip Y', Icons.flip_camera_android, flipVertical),
                              toolButton('Reset', Icons.restart_alt, reset),
                              toolButton('Save', Icons.save_alt, save),
                              toolButton('Share', Icons.share, share),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Text('Filter: $filter'),
                          SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: Row(
                              children: filters.map((name) {
                                return Padding(
                                  padding: const EdgeInsets.only(right: 6),
                                  child: ChoiceChip(
                                    label: Text(name),
                                    selected: filter == name,
                                    onSelected: editedBytes == null
                                        ? null
                                        : (_) async {
                                            filter = name;
                                            await applyAdjustments();
                                            if (mounted) setState(() {});
                                          },
                                  ),
                                );
                              }).toList(),
                            ),
                          ),
                          _slider(
                            'Brightness',
                            brightness,
                            -1,
                            1,
                            (v) => setState(() => brightness = v),
                          ),
                          _slider(
                            'Contrast',
                            contrast,
                            -1,
                            1,
                            (v) => setState(() => contrast = v),
                          ),
                          _slider(
                            'Saturation',
                            saturation,
                            -1,
                            1,
                            (v) => setState(() => saturation = v),
                          ),
                          FilledButton.icon(
                            onPressed: editedBytes == null ? null : applyAdjustments,
                            icon: const Icon(Icons.tune),
                            label: const Text('Terapkan Adjustments'),
                          ),
                          const SizedBox(height: 8),
                          Text('History: ${history.length} langkah'),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _slider(
    String label,
    double value,
    double min,
    double max,
    ValueChanged<double> onChanged,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text('$label  ${value.toStringAsFixed(2)}'),
        Slider(
          value: value,
          min: min,
          max: max,
          onChanged: editedBytes == null ? null : onChanged,
        ),
      ],
    );
  }

  Widget _emptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.photo_camera_back_outlined,
              size: 84,
              color: Theme.of(context).colorScheme.primary,
            ),
            const SizedBox(height: 16),
            const Text(
              'Pilih foto untuk mulai mengedit',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              'Camera atau Gallery tersedia. Setelah foto masuk, semua alat editor muncul di bawah.',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
