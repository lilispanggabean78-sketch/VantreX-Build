# POTO GRAPER — Flutter Release Ready

Fitur:
- Camera
- Gallery / multi-photo selection
- Crop
- Rotate
- Flip horizontal / vertical
- Brightness
- Contrast
- Saturation
- Preset filters
- Reset
- Save/export
- Share
- Edit history
- Dark/light mode
- Android release configuration

## Build

```bash
flutter pub get
flutter analyze
flutter build apk --release
```

Jika dipakai pada workflow build yang mencari `build-assets/icon.*`, jangan hapus folder `build-assets` di samping folder `photo_studio`.

## Struktur ZIP

```text
photo_studio_release_ready.zip
├── photo_studio/
└── build-assets/
    └── icon.png
```
