import 'package:flutter_test/flutter_test.dart';
import 'package:photo_studio/main.dart';

void main() {
  testWidgets('Photo Studio starts', (tester) async {
    await tester.pumpWidget(const PhotoStudioApp());
    expect(find.text('Photo Studio'), findsOneWidget);
  });
}
