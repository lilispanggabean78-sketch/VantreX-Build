import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../services/history_service.dart';

class HomeScreen extends StatefulWidget {
  final bool isDark;
  final VoidCallback onTheme;
  const HomeScreen({super.key, required this.isDark, required this.onTheme});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final picker = ImagePicker();
  String? path;
  List<String> history = [];
  int tab = 0;

  double brightness = 0;
  double contrast = 1;
  double saturation = 1;
  double rotation = 0;
  bool flipX = false;
  bool flipY = false;
  String filter = 'Original';

  final filters = const [
    'Original','Mono','Warm','Cool','Vintage','Sepia','Dramatic'
  ];

  @override
  void initState() {
    super.initState();
    loadHistory();
  }

  Future<void> loadHistory() async {
    final h = await HistoryService.getAll();
    if (mounted) setState(() => history = h);
  }

  Future<void> choose(ImageSource source) async {
    final x = await picker.pickImage(source: source, imageQuality: 100);
    if (x == null) return;
    setState(() {
      path = x.path;
      resetValues();
      tab = 0;
    });
    await HistoryService.add(x.path);
    await loadHistory();
  }

  void resetValues() {
    brightness = 0;
    contrast = 1;
    saturation = 1;
    rotation = 0;
    flipX = false;
    flipY = false;
    filter = 'Original';
  }

  Future<void> crop() async {
    if (path == null) return;
    final result = await ImageCropper().cropImage(
      sourcePath: path!,
      compressQuality: 100,
      uiSettings: [
        AndroidUiSettings(
          toolbarTitle: 'Crop',
          toolbarColor: Colors.deepPurple,
          toolbarWidgetColor: Colors.white,
          lockAspectRatio: false,
        ),
        IOSUiSettings(title: 'Crop'),
      ],
    );
    if (result != null) {
      setState(() => path = result.path);
      await HistoryService.add(result.path);
      await loadHistory();
    }
  }

  ColorFilter get matrix {
    if (filter == 'Mono') {
      return const ColorFilter.matrix([
        .2126,.7152,.0722,0,0,.2126,.7152,.0722,0,0,
        .2126,.7152,.0722,0,0,0,0,0,1,0
      ]);
    }
    if (filter == 'Warm') {
      return const ColorFilter.matrix([
        1.08,0,0,0,8,0,1.02,0,0,2,0,0,.9,0,-2,0,0,0,1,0
      ]);
    }
    if (filter == 'Cool') {
      return const ColorFilter.matrix([
        .92,0,0,0,0,0,1,0,0,0,0,0,1.1,0,8,0,0,0,1,0
      ]);
    }
    if (filter == 'Vintage') {
      return const ColorFilter.matrix([
        .9,.05,.02,0,12,.02,.82,.04,0,8,0,.06,.7,0,2,0,0,0,1,0
      ]);
    }
    if (filter == 'Sepia') {
      return const ColorFilter.matrix([
        .393,.769,.189,0,0,.349,.686,.168,0,0,.272,.534,.131,0,0,0,0,0,1,0
      ]);
    }
    if (filter == 'Dramatic') {
      return const ColorFilter.matrix([
        1.35,0,0,0,-40,0,1.35,0,0,-40,0,0,1.35,0,-40,0,0,0,1,0
      ]);
    }

    final s = saturation;
    final sr = .213 * (1-s);
    final sg = .715 * (1-s);
    final sb = .072 * (1-s);
    final c = contrast;
    final b = brightness;
    return ColorFilter.matrix([
      c*(sr+s),c*sg,c*sb,0,b,
      c*sr,c*(sg+s),c*sb,0,b,
      c*sr,c*sg,c*(sb+s),0,b,
      0,0,0,1,0
    ]);
  }

  Widget preview() {
    if (path == null) {
      return const Center(child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.photo_library_outlined, size: 76),
          SizedBox(height: 12),
          Text('Belum ada foto'),
          SizedBox(height: 5),
          Text('Pilih dari galeri atau gunakan kamera'),
        ],
      ));
    }
    Widget w = Image.file(
      File(path!),
      fit: BoxFit.contain,
      errorBuilder: (_,__,___) => const Center(child: Text('Gagal membuka foto')),
    );
    w = ColorFiltered(colorFilter: matrix, child: w);
    w = Transform(
      alignment: Alignment.center,
      transform: Matrix4.identity()
        ..rotateZ(rotation * 3.141592653589793 / 180)
        ..scale(flipX ? -1.0 : 1.0, flipY ? -1.0 : 1.0),
      child: w,
    );
    return Center(child: w);
  }

  Future<String?> saveEdited() async {
    if (path == null) return null;
    final source = img.decodeImage(await File(path!).readAsBytes());
    if (source == null) return null;

    var edited = source;
    if (rotation % 360 != 0) {
      edited = img.copyRotate(edited, angle: rotation.round());
    }
    if (flipX) edited = img.flipHorizontal(edited);
    if (flipY) edited = img.flipVertical(edited);

    if (brightness != 0) {
      edited = img.adjustColor(edited, brightness: brightness);
    }
    if (contrast != 1) {
      edited = img.adjustColor(edited, contrast: contrast);
    }
    if (saturation != 1) {
      edited = img.adjustColor(edited, saturation: saturation);
    }

    if (filter == 'Mono') {
      edited = img.grayscale(edited);
    } else if (filter == 'Sepia') {
      edited = img.sepia(edited);
    }

    final bytes = Uint8List.fromList(img.encodeJpg(edited, quality: 95));
    final dir = await getApplicationDocumentsDirectory();
    final out = File('${dir.path}/edited_${DateTime.now().millisecondsSinceEpoch}.jpg');
    await out.writeAsBytes(bytes);
    await HistoryService.add(out.path);
    await loadHistory();
    return out.path;
  }

  Future<void> save() async {
    final result = await saveEdited();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(result == null ? 'Gagal menyimpan' : 'Foto tersimpan')),
    );
  }

  Future<void> share() async {
    final result = await saveEdited();
    if (result == null) return;
    await Share.shareXFiles([XFile(result)], text: 'Photo Studio');
  }

  void resetAll() => setState(resetValues);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Photo Studio', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            tooltip: 'Dark / Light',
            onPressed: widget.onTheme,
            icon: Icon(widget.isDark ? Icons.light_mode : Icons.dark_mode),
          ),
          PopupMenuButton<String>(
            onSelected: (v) async {
              if (v == 'clear') {
                await HistoryService.clear();
                await loadHistory();
              }
              if (v == 'about' && mounted) {
                showAboutDialog(
                  context: context,
                  applicationName: 'Photo Studio',
                  applicationVersion: '1.0.0',
                  applicationLegalese: 'Flutter Photo Studio',
                );
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'about', child: Text('Tentang')),
              PopupMenuItem(value: 'clear', child: Text('Hapus riwayat')),
            ],
          )
        ],
      ),
      body: tab == 1 ? historyView() : editorView(),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.tune), label: 'Editor'),
          NavigationDestination(icon: Icon(Icons.history), label: 'History'),
        ],
      ),
      floatingActionButton: tab == 0 ? FloatingActionButton(
        onPressed: () => choose(ImageSource.gallery),
        child: const Icon(Icons.add_photo_alternate),
      ) : null,
    );
  }

  Widget editorView() {
    final has = path != null;
    return Column(children: [
      Expanded(
        child: Container(
          margin: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
          ),
          clipBehavior: Clip.antiAlias,
          child: preview(),
        ),
      ),
      if (!has) ...[
        Padding(
          padding: const EdgeInsets.fromLTRB(12,0,12,18),
          child: Row(children: [
            Expanded(child: FilledButton.icon(
              onPressed: () => choose(ImageSource.gallery),
              icon: const Icon(Icons.photo_library), label: const Text('Galeri'))),
            const SizedBox(width: 10),
            Expanded(child: OutlinedButton.icon(
              onPressed: () => choose(ImageSource.camera),
              icon: const Icon(Icons.camera_alt), label: const Text('Kamera'))),
          ]),
        )
      ] else ...[
        SizedBox(
          height: 48,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            children: [
              tool('Crop', Icons.crop, crop),
              tool('↶', Icons.rotate_left, () => setState(() => rotation -= 90)),
              tool('↷', Icons.rotate_right, () => setState(() => rotation += 90)),
              tool('Flip X', Icons.flip, () => setState(() => flipX = !flipX)),
              tool('Flip Y', Icons.flip, () => setState(() => flipY = !flipY)),
              tool('Reset', Icons.restart_alt, resetAll),
            ],
          ),
        ),
        SizedBox(
          height: 48,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            children: filters.map((f) => Padding(
              padding: const EdgeInsets.only(right: 7),
              child: ChoiceChip(
                label: Text(f),
                selected: filter == f,
                onSelected: (_) => setState(() => filter = f),
              ),
            )).toList(),
          ),
        ),
        slider('Brightness', brightness, -100, 100, (v) => setState(() => brightness=v)),
        slider('Contrast', contrast, .5, 2, (v) => setState(() => contrast=v)),
        slider('Saturation', saturation, 0, 2, (v) => setState(() => saturation=v)),
        Padding(
          padding: const EdgeInsets.fromLTRB(12,0,12,14),
          child: Row(children: [
            Expanded(child: FilledButton.icon(onPressed: save, icon: const Icon(Icons.save), label: const Text('Simpan'))),
            const SizedBox(width: 8),
            Expanded(child: OutlinedButton.icon(onPressed: share, icon: const Icon(Icons.share), label: const Text('Share'))),
          ]),
        )
      ],
    ]);
  }

  Widget tool(String text, IconData icon, VoidCallback onTap) => Padding(
    padding: const EdgeInsets.only(right: 8),
    child: ActionChip(avatar: Icon(icon), label: Text(text), onPressed: onTap),
  );

  Widget slider(String name, double value, double min, double max, ValueChanged<double> fn) =>
    Row(children: [
      SizedBox(width: 95, child: Padding(
        padding: const EdgeInsets.only(left: 12), child: Text(name))),
      Expanded(child: Slider(value: value.clamp(min,max), min:min, max:max, onChanged: fn))
    ]);

  Widget historyView() {
    if (history.isEmpty) return const Center(child: Text('Belum ada foto di history'));
    return GridView.builder(
      padding: const EdgeInsets.all(12),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3, crossAxisSpacing: 8, mainAxisSpacing: 8),
      itemCount: history.length,
      itemBuilder: (_, i) {
        final p = history[i];
        return GestureDetector(
          onTap: () {
            if (File(p).existsSync()) setState(() {
              path = p; resetValues(); tab = 0;
            });
          },
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.file(File(p), fit: BoxFit.cover,
              errorBuilder: (_,__,___) => const ColoredBox(
                color: Colors.black12, child: Icon(Icons.broken_image))),
          ),
        );
      },
    );
  }
}
