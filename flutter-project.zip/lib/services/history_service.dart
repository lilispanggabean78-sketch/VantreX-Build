import 'package:shared_preferences/shared_preferences.dart';

class HistoryService {
  static const key = 'photo_history';

  static Future<List<String>> getAll() async {
    final p = await SharedPreferences.getInstance();
    return p.getStringList(key) ?? [];
  }

  static Future<void> add(String path) async {
    final p = await SharedPreferences.getInstance();
    final list = p.getStringList(key) ?? [];
    list.remove(path);
    list.insert(0, path);
    if (list.length > 50) list.removeRange(50, list.length);
    await p.setStringList(key, list);
  }

  static Future<void> clear() async {
    final p = await SharedPreferences.getInstance();
    await p.remove(key);
  }
}
