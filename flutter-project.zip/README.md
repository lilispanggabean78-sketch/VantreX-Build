# Photo Studio

Flutter photo editor base dengan:
- Camera
- Gallery
- Crop
- Rotate
- Flip horizontal/vertical
- Brightness
- Contrast
- Saturation
- Filter Original, Mono, Warm, Cool, Vintage, Sepia, Dramatic
- Undo/Redo
- Save hasil edit ke storage aplikasi
- Share
- History
- Dark mode
- About

## Build
flutter pub get
flutter analyze
flutter build apk --release

Output:
build/app/outputs/flutter-apk/app-release.apk

Catatan:
`pubspec.lock`, `.dart_tool`, build cache, dan Gradle wrapper binary dibuat oleh Flutter SDK saat menjalankan `flutter pub get`/`flutter build`; jangan mengarang binary tersebut karena harus cocok dengan Flutter SDK yang digunakan.
