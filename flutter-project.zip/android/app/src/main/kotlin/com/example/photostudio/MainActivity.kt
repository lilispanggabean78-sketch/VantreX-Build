package com.example.photostudio

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
